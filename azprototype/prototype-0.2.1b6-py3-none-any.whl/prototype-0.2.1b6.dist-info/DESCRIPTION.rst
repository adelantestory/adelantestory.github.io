Empowers customers to rapidly create Azure prototypes using AI-driven agent teams.
